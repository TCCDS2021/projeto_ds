﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PROJETO_ATIVIDADE.DTO;

namespace PROJETO_ATIVIDADE.DAL
{
    class loginDAL
    { 
        //lista de dados (usuarios e senhas)
        public List<LoginDTO> usuariosLogin = new List<LoginDTO> { 
            new LoginDTO(){Usuario = "Jeniffer", Senha ="12345"},
            new LoginDTO(){Usuario = "Davi", Senha ="12345"},
            new LoginDTO(){Usuario = "Alex", Senha ="12345"},
            new LoginDTO(){Usuario = "Vinicius", Senha ="12345"},
        };

        //metodo que retorna a lista de usuarios
        public List<LoginDTO> RetornaListaLogin()
        {
            return usuariosLogin;
        }
    }
}
