﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PROJETO_ATIVIDADE.DTO;
using PROJETO_ATIVIDADE.DAL;

namespace PROJETO_ATIVIDADE.BLL
{
    class loginBLL
    {
        //metodo de login

        public bool Logar(LoginDTO loginDTO)
        {
            //acesso ao banco de dados (DAL) criar objeto
            //receber os dados do UI pelo DTO

            loginDAL lista = new loginDAL();

            //variavel que recebe a kisuta do banco de dados 

            var login = lista.RetornaListaLogin();
            
            //pesquisar na lista de usuarios (DAL) se os dados enviados pela UI conferem 

            foreach(var usuarioLogin in login)
            {
                if (loginDTO.Usuario == usuarioLogin.Usuario && loginDTO.Senha == usuarioLogin.Senha )
                {
                    return true;
                }
            }

            return false;

        }
    }
}
