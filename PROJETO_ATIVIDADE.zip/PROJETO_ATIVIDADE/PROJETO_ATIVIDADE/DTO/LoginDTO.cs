﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJETO_ATIVIDADE.DTO
{
    class LoginDTO
    {
        public string Usuario { get; set; }

        public string Senha { get; set; }
        
        public bool DefineUsuario(string usuario)
        {
            if (usuario !="")
            {
                Usuario = usuario;
                return true;
            }

            return false;
        }


        public bool DefineSenha(string senha)
        {
            if (senha != "")
            {
                 Senha = senha;
                return true;
            }

            return false;
        }

    }
}
