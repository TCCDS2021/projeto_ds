﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PROJETO_ATIVIDADE.DTO;
using PROJETO_ATIVIDADE.BLL;
using MySql.Data.MySqlClient;

namespace PROJETO_ATIVIDADE
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

       

        private void btn_entrar_Click(object sender, EventArgs e)
        {
            //usar a camada de transporte
            LoginDTO login = new LoginDTO();

            var usuario = login.DefineUsuario(txt_usuario.Text);
            var senha = login.DefineSenha(txt_senha.Text);

            //receber os dados do formulario e atribuir ao DTO
            login.DefineUsuario(txt_usuario.Text);
            login.DefineSenha(txt_senha.Text);
            /*
            if(usuario && senha)
            { */
             //chamar o metodo da camada de logar DLL
            loginBLL logar = new loginBLL();

               var retorno = logar.Logar(login);

                if(retorno)
                {
                    MessageBox.Show("Login realizado");
                }
                else
                {
                    MessageBox.Show("Usuario e senha inválido");
                }
            
            /*
            else
            {
                MessageBox.Show("Preencha corretamente os campos");
            }*/
        }

    }
}
